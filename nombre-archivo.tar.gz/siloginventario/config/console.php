<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Console routes filter
	|--------------------------------------------------------------------------
	|
	| Set filter used for managing access to the console. By default, filter
	| 'console_whitelist' allows only people from 'whitelist' array below.
	|
	*/

	'middleware' => null,

);
