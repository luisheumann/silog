@extends('app')

@section('content')
<div class="container">
	 @include('locationProducts.show_fields')
</div>
@endsection
