@extends('app')

@section('content')
<div class="container">
	 @include('brands.show_fields')
</div>
@endsection
