@extends('app')

@section('content')
<div class="container">
	 @include('productDetails.show_fields')
</div>
@endsection
