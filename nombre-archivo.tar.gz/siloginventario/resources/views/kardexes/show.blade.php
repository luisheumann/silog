@extends('app')

@section('content')
<div class="container">
	 @include('kardexes.show_fields')
</div>
@endsection
