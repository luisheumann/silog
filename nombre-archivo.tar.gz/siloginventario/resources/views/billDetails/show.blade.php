@extends('app')

@section('content')
<div class="container">
	 @include('billDetails.show_fields')
</div>
@endsection
