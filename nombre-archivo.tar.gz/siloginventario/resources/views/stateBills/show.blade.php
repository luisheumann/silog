@extends('app')

@section('content')
<div class="container">
	 @include('stateBills.show_fields')
</div>
@endsection
