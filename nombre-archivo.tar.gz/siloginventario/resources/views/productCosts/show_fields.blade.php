<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $productCost->id !!}</p>
</div>

<!-- Id Sucursal Field -->
<div class="form-group">
    {!! Form::label('id_sucursal', 'Id Sucursal:') !!}
    <p>{!! $productCost->id_sucursal !!}</p>
</div>

<!-- Product Detail Id Field -->
<div class="form-group">
    {!! Form::label('product_detail_id', 'Product Detail Id:') !!}
    <p>{!! $productCost->product_detail_id !!}</p>
</div>

<!-- Rule Sale Id Field -->
<div class="form-group">
    {!! Form::label('rule_sale_id', 'Rule Sale Id:') !!}
    <p>{!! $productCost->rule_sale_id !!}</p>
</div>

<!-- Fecha Inicio Field -->
<div class="form-group">
    {!! Form::label('fecha_inicio', 'Fecha Inicio:') !!}
    <p>{!! $productCost->fecha_inicio !!}</p>
</div>

<!-- Fecha Fin Field -->
<div class="form-group">
    {!! Form::label('fecha_fin', 'Fecha Fin:') !!}
    <p>{!! $productCost->fecha_fin !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $productCost->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $productCost->updated_at !!}</p>
</div>

