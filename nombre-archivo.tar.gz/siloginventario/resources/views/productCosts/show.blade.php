@extends('app')

@section('content')
<div class="container">
	 @include('productCosts.show_fields')
</div>
@endsection
