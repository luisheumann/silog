@extends('app')

@section('content')
<div class="container">
	 @include('purchaseOrderDetails.show_fields')
</div>
@endsection
