@extends('app')

@section('content')
<div class="container">
	 @include('formPayments.show_fields')
</div>
@endsection
