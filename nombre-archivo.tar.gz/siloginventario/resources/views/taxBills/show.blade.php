@extends('app')

@section('content')
<div class="container">
	 @include('taxBills.show_fields')
</div>
@endsection
