@extends('app')

@section('content')
 
<div class="container">
	 @include('categories.show_fields')
</div>
@endsection
