@extends('app')

@section('content')
<div class="container">
	 @include('locations.show_fields')
</div>
@endsection
