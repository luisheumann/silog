@extends('app')

@section('content')
<div class="container">
	 @include('ruleSales.show_fields')
</div>
@endsection
