@extends('app')

@section('content')
<div class="container">
	 @include('products.show_fields')
</div>
@endsection
