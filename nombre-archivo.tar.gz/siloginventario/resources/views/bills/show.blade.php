@extends('app')

@section('content')
<div class="container">
	 @include('bills.show_fields')
</div>
@endsection
