@extends('app')

@section('content')
<div class="container">
	 @include('taxes.show_fields')
</div>
@endsection
